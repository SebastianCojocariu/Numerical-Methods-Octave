function x=morse_encode(c);
a=morse();
rez='';
%verific daca ce mi s-a dat la input e litera mare;
if(c<'A'||c>'Z')
  x='*';
  return;
else
%apelam functia de cautare;
  morse_encode_cautare(a,c,rez);
endif
endfunction
