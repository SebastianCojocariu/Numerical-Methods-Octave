function x=multiple_decode(sir)
x='';
i=1;
rez='';
%parcurgem sirul dat
while(i<=length(sir))
%daca dam de o litera,formam cuvantul pentru codificat
while(i<=length(sir)&&sir(i)!=' ')

rez=strcat(rez,sir(i));
i++;
endwhile

%decodificam cu functia morse_decode
x=strcat(x,morse_decode(rez));
x=strcat(x,' ');
rez='';
%daca i>length(sir) iesim din functie
if(i>length(sir))
  return;
endif
%daca dam de un spatiu parcurgem spatiile pana cand dam de litere;
while(i<=length(sir)&&sir(i)==' ')
i++;
endwhile

endwhile



endfunction