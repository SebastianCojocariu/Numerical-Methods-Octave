function [x]=morse_encode_cautare(a,c,rez)
%verific daca elementul cautat e chiar in frunza in care ma aflu.
%Daca da,returnez si ies.
if(isempty(a{1,1})==0)
  if(a{1,1}==c)
    x=rez;
    return ;
  endif;
endif
%verific daca ma pot duce mai la stanga in arbore
%In caz afirmativ retin in rez1 noua "codificare" si apelez recursiv pentru stanga

if(isempty(a{1,2})==0)
  rez1=rez;
  rez1=strcat(rez1,'.');
  morse_encode_cautare(a{1,2},c,rez1)
endif
   
%verific daca ma pot duce mai la dreapta in arbore
%In caz afirmativ retin in rez2 noua "codificare" si apelez recursiv pentru dreapta

if(isempty(a{1,3})==0)
  rez2=rez;
  rez2=strcat(rez2,'-');
  morse_encode_cautare(a{1,3},c,rez2)
endif

endfunction