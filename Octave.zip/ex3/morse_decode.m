function x=morse_decode(sir)
rezultat=morse();
%parcurgem arborele conform sirului.
for i=1:length(sir)
%verificm ca sirul sa cuprinda doar caracterele '.' si '-',in caz contrar exit;
  if(sir(i)!='.'&&sir(i)!='-')
    x="*";
    return;
  endif
  
  if(sir(i)=='.')
  %daca nu se poate duce mai la stanga x='*';
    if(isempty(rezultat{1,2})==1)
    x="*";
    return;
  else
  %altfel ma duc mai departe la stanga
    rezultat=rezultat{1,2};
  endif
  endif
  
  if(sir(i)=='-')
    if(isempty(rezultat{1,3})==1)
    %daca nu se poate duce mai la stanga x='*';
    x="*";
    return;
  else
  %altfel ma duc mai departe la stanga
    rezultat=rezultat{1,3};
  endif
  endif
endfor
%afisez valoarea
x=rezultat{1,1};
endfunction