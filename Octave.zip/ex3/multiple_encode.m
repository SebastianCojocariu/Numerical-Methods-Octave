function x=multiple_encode(sir)

for i=1:length(sir)
    if(sir(i)<'A'||sir(i)>'Z')
      disp("nu se poate codifica\n")
      return;
    endif
    morse_encode(sir(i));
   
   
endfor
endfunction
    