function [a]=strategie_calculator(a,semn_utilizator,semn_calculator)
%Verifica daca poate sa castige
for i=1:3
  for j=1:3
    b=a;
    if(b(i,j)!=semn_calculator&&b(i,j)!=semn_utilizator)
      b(i,j)=semn_calculator;
    endif
    
    if(castigare(b)==semn_calculator)
      a(i,j)=semn_calculator;
      return;
    endif
  endfor
endfor

%Verifica daca poate bloca adversarul

for i=1:3
  for j=1:3
    b=a;
    if(b(i,j)!=semn_calculator&&b(i,j)!=semn_utilizator)
      b(i,j)=semn_utilizator;
    endif
    
    if(castigare(b)==semn_utilizator)
      a(i,j)=semn_calculator;
      return;
    endif
  endfor
endfor

%incearca sa puna in mijloc

if(a(2,2)!=semn_calculator&&a(2,2)!=semn_utilizator)
  a(2,2)=semn_calculator;
  return;
endif;

%incearca sa puna in colturi
if(a(1,1)!=semn_calculator&&a(1,1)!=semn_utilizator)
  a(1,1)=semn_calculator;
  return;
endif

if(a(1,3)!=semn_calculator&&a(1,3)!=semn_utilizator)
  a(1,3)=semn_calculator;
  return;
endif

if(a(3,1)!=semn_calculator&&a(3,1)!=semn_utilizator)
  a(3,1)=semn_calculator;
  return;
endif

if(a(3,3)!=semn_calculator&&a(3,3)!=semn_utilizator)
  a(3,3)=semn_calculator;
  return;
endif

%daca nu a facut niciunul dintre pasii de mai sus pune poate
for i=1:3
  for j=1:3
   
    if(a(i,j)!=semn_calculator&&a(i,j)!=semn_utilizator)
      a(i,j)=semn_calculator;
      return;
    endif
  endfor
endfor
endfunction
