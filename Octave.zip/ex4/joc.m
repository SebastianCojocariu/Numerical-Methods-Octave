function []=joc();
rez=1;
a=[10 11 12; 13 14 15;16 17 18];
%numarul de partide castigate ;
nr_utilizator=0;
nr_calculator=0;  
%acest prim while are rolul de a repeta jocul ori de cate ori utilizatorul
%apasa 1.La fiecare apasare a lui 9 programul se inchide
while(rez==1)
x=input("Alegeti cu ce vreti sa jucati.Introduceti 0 pentru O,respectiv 1 pentru X\n");
if(x==9)
  return;
endif
while(x!=1&&x!=0)
x=input("Alegeti cu ce vreti sa jucati.Introduceti 0 pentru O,respectiv 1 pentru X.Apasati 9 pentru a iesi\n");
if(x==9)
  return;
endif
endwhile

%Verificam ce a ales utilizatorul si cine este primul.
if(x==1)
  semn_utilizator='X'
  semn_calculator='O'
  primul='utilizator';
elseif(x==0)
  semn_calculator='X'
  semn_utilizator='O'
  primul='calculator';
endif


%cazul cand primul este utilizatorul,deci semnul lui este X
if(primul=='utilizator')
i=0;
while(i<=8&&castigare(a)=='nimeni')
i+=2;
x=input("Alegeti linia pe care doriti sa puneti.Apasati 9 pentru a iesi\n");
if(x==9)
  return;
endif

y=input("Alegeti coloana pe care doriti sa puneti.Apasati 9 pentru a iesi\n");
if(y==9)
  return;
endif

while(x<1||x>3||y<1||y>3||a(x,y)==semn_calculator||a(x,y)==semn_utilizator)
printf("Ati introdus niste coordonate gresite.Icercati din nou\n")
x=input("Alegeti linia pe care doriti sa puneti.Apasati 9 pentru a iesi\n");
y=input("Alegeti coloana pe care doriti sa puneti.Apasati 9 pentru a iesi\n");
if(x==9||y==9) return;
endif
endwhile



a(x,y)=semn_utilizator;
afisare(a);
if(i!=10)
a=strategie_calculator(a,semn_utilizator,semn_calculator);
afisare(a);
endif

endwhile


% Verificam daca cel care incepe primul e calculator,
%adica utilizatorul a ales sa joace cu O.

elseif(primul=='calculator')
i=0;
while(i<=8&&castigare(a)=='nimeni')
i+=2;

a=strategie_calculator(a,semn_utilizator,semn_calculator);
afisare(a);

if(i!=10&&castigare(a)=='nimeni')
x=input("Alegeti linia pe care doriti sa puneti.Apasati 9 pentru a iesi\n");
if(x==9)
  return;
endif

y=input("Alegeti coloana pe care doriti sa puneti.Apasati 9 pentru a iesi\n");
if(y==9)
  return;
endif

while(x<1||x>3||y<1||y>3||a(x,y)==semn_calculator||a(x,y)==semn_utilizator)
printf("Ati introdus niste coordonate gresite.Icercati din nou\n")
x=input("Alegeti linia pe care doriti sa puneti.Apasati 9 pentru a iesi\n");
y=input("Alegeti coloana pe care doriti sa puneti.Apasati 9 pentru a iesi\n");
if(x==9||y==9) return;
endif
endwhile



a(x,y)=semn_utilizator;
afisare(a);
endif
endwhile
endif
%la sfarsitul acestui if(care are legatura cu ce a ales jucatorul sa joace)
%vedem cine a castigat
if(castigare(a)=='nimeni')
disp("Remiza");

elseif(castigare(a)==semn_utilizator)
  nr_utilizator++;
else  
  nr_calculator++;
endif
a=resetare_tabla;
%scorul
printf("Scorul este:Calculator %d - %d Utilizator\n",nr_calculator,nr_utilizator);
%cat timp rez=1 se continua cu un alt joc,iar cu 0 sau 9 se iese.
rez=input("Doriti sa mai jucati un joc?Apasati 1 pentru DA si 0 pentru NU\n");
if(rez==0||rez==9)
  return;
while(rez!=0&&rez!=1)
rez=input("Ati introdus o valoare gresita.Doriti sa mai jucati un joc?Apasati 1 pentru DA si 0 pentru NU\n");
if(rez==9)
  return;
endif
endwhile
endif



endwhile

endfunction
