function [a]=resetare_tabla();
a=[10 11 12;13 14 15;16 17 18];
endfunction

%resetare tabla la valorile de inceput