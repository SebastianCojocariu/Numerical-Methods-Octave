function []=afisare(a)
%Afisam prima linie
if(a(1,1)=='X'||a(1,1)=='O') 
  printf(" %c|",a(1,1))
else 
  printf("  |")
endif

if(a(1,2)=='X'||a(1,2)=='O') 
  printf(" %c|",a(1,2))
else 
  printf("  |")
endif

if(a(1,3)=='X'||a(1,3)=='O') 
  printf(" %c|",a(1,3))
else 
  printf("  |")
endif

printf("\n__|__|__|\n")

%Afisam a doua linie
if(a(2,1)=='X'||a(2,1)=='O') 
  printf(" %c|",a(2,1))
else 
  printf("  |")
endif

if(a(2,2)=='X'||a(2,2)=='O') 
  printf(" %c|",a(2,2))
else 
  printf("  |")
endif

if(a(2,3)=='X'||a(2,3)=='O') 
  printf(" %c|",a(2,3))
else
  printf("  |")
endif

printf("\n__|__|__|\n");


%Afisam a treia linie
if(a(3,1)=='X'||a(3,1)=='O') 
  printf(" %c|",a(3,1))
else 
  printf("  |")
endif

if(a(3,2)=='X'||a(3,2)=='O') 
  printf(" %c|",a(3,2))
else 
  printf("  |")
endif

if(a(3,3)=='X'||a(3,3)=='O') 
  printf(" %c|",a(3,3))
else 
  printf("  |")
endif

printf("\n__|__|__|\n\n")
endfunction

