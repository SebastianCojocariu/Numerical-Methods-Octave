function [Castigator]=castigare(a)
%verifcam diagonala principala
if(a(1,1)==a(2,2)&&a(1,1)==a(3,3))
  Castigator=a(1,1);
  return
endif
%verificam diag secundara
if(a(1,3)==a(2,2)&&a(3,1)==a(2,2))
  Castigator=a(1,3);
  return
endif
%verificam liniile
for i=1:3
   if(a(i,1)==a(i,2)&&a(i,1)==a(i,3))
    Castigator=a(i,1);
    return;
   endif
endfor

%verificam coloanele
for i=1:3
   if(a(1,i)==a(2,i)&&a(1,i)==a(3,i))
    Castigator=a(1,i);
    return;
   endif
endfor
Castigator="nimeni";
endfunction
