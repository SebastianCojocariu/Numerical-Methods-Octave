function r=baza(sursa,b1,b2)

%Verificam daca bazele respecta conditiile
if(b1<2||b2<2||b1>30||b2>30)
  printf("bazele nu sunt cuprinse intre 2 si 30\n");
  return;
endif

v="0123456789abcdefghijklmnopqrst";
s=0;
sursa=tolower(sursa);
p=power(b1,length(sursa)-1);

for i=1:length(sursa)
  %Verificam daca cifrele se incadreaza in baza data(b1)
  ok=0;
  for j=1:b1  
    if(sursa(i)==v(j))
    ok=1;
    break;
    endif;
  endfor
  if(ok==0) 
    printf("Cifrele numarului nu respecta baza in care se afla\n");
    return;
  endif

  if(sursa(i)>=48&&sursa(i)<=57) 
    x=sursa(i)-'0';
  else
    x=sursa(i)-'a'+10;
  endif
%formam numarul dat in baza 10,memorat in s
  s=s+x*p;
  p=p/b1;
endfor

%folosim regula de transformare din baza 10 in baza b2.Retinem resturile la imaparirea cu b2 is le punem in ordine inversa;
rez1='';
while(s>0)
  rest=mod(s,b2);
  s=floor(s/b2);
  rez1=strcat(rez1,v(rest+1));
endwhile 
r='';
%inversam "cifrele"
for i=1:length(rez1)
  r=strcat(r,rez1(length(rez1)-i+1));
endfor
endfunction
