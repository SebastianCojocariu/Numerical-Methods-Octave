function Z=zigzag(n)
a=zeros(n);

%am gasit formula pentru elementele de pe prima linie
for i=1:n/2
    a(1,2*i)=(2*i-1)*i;
    a(1,2*i-1)=a(1,2*i)-1;
endfor
%daca n e impar trebuie sa ii dam valoarea de mai jos
if(mod(n,2)==1)
a(1,n)=n*(n+1)/2-1;
endif
%folosim functiile din arhiva pentru a cobora de la fiecare element a(i,j)
%cu mentiunea ca pentru i par se aduna,iar pentru i impar se scade
for i=2:n
  if(mod(i,2)==0)
    a=coborare_adunare(1,i,a,n,a(1,i));
  else
    a=coborare_scadere(1,i,a,n,a(1,i));
  endif
endfor

%pana aici am completat matricea de la diagonala secundata in sus
%Completam mai departe ce a ramas(dedesubtul diagonalei)
%se demonstreaza imediat ca a(i,j)+a(n+1-i,n+1-j)=n*n-1.
s=n*n-1;
for i=1:n
  for j=1:(n+1-i)
    a(n+1-i,n+1-j)=s-a(i,j);
endfor
endfor
Z=a;
endfunction  