function [a]=coborare_adunare(i,j,a,n,s)
a(i,j)=s;
while(j!=1&&i!=n)
    s++;
    a(++i,--j)=s;
endwhile
endfunction

%functia coboara in diagonala de la pozitia i,j si incrementeaza la fiecare pas valoarea initiala a(i,j)